# PZ-7_7-1
Given the alphabet {1, ... , 8}. Will compose all arrangements of 5 elements and output their file + output the number of elements.
